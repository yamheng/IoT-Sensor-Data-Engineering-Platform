# IoT Sensor Data Engineering Platform

This is my Big Data Engineering practical project. I built a local pipeline for IoT sensor readings, using the tools from the lab sessions.

The flow is:

```text
Python producer -> Kafka -> Spark Structured Streaming -> local data lake -> Spark SQL analytics -> Flask API
```

The sensors are `temperature`, `humidity` and `pressure`. The producer sends JSON messages to Kafka. Spark reads them, cleans them, detects anomalies, and writes the data lake.

## Architecture

```text
+------------------+
| Python producer  |
| src/producer.py  |
+--------+---------+
         |
         v
+-----------------------------+
| Kafka cluster, 3 brokers    |
| topic: sensor-events        |
+--------+--------------------+
         |
         v
+-----------------------------+
| Spark Structured Streaming  |
| src/spark_pipeline.py       |
| parse, clean, anomalies     |
| 5-minute windows            |
+--------+--------------------+
         |
         v
+-----------------------------+
| Local data lake             |
| raw / curated / consumption |
+--------+--------------------+
         |
         +--------------------+
         |                    |
         v                    v
+------------------+   +------------------+
| Spark analytics  |   | Flask REST API   |
| src/analytics.py |   | src/api/app.py   |
+------------------+   +------------------+
```

Data lake layout used in my run:

```text
D:/tmp/datalake/
  raw/source=kafka/topic=sensor-events/year=YYYY/month=MM/day=DD/hour=HH/
  curated/domain=iot/sensor_type=.../year=YYYY/month=MM/day=DD/
  consumption/use_case=sensor_averages/sensor_type=.../year=YYYY/month=MM/
```

On Linux or WSL2, `/tmp/datalake` can be used instead.

## Project structure

```text
.
|-- README.md
|-- docker-compose.yml
|-- requirements.txt
|-- docs/
|   |-- analytics.md
|   |-- fault_tolerance.md
|   |-- architecture.md
|   `-- reflection.md
|-- src/
|   |-- producer.py
|   |-- spark_pipeline.py
|   |-- analytics.py
|   `-- api/
|       |-- app.py
|       |-- kafka_utils.py
|       `-- lake_utils.py
|-- outputs/
|   |-- analytics/
|   `-- screenshots/
`-- tests/
    `-- test_curl_commands.sh
```

## Prerequisites

Versions I used:

```text
Docker / Docker Compose
Python 3.11
PySpark 3.5.3
Flask 3.1.3
kafka-python-ng 2.2.3
```

Install the Python packages:

```powershell
pip install -r requirements.txt
```

## Running the project

### 1. Start Kafka

```powershell
docker compose up -d
```

Check containers:

```powershell
docker ps
```

I expect to see `kafka1`, `kafka2`, `kafka3` and `kafka-ui`.

Kafka UI:

```text
http://localhost:8080
```

### 2. Create the topic

```powershell
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --create --topic sensor-events --partitions 3 --replication-factor 3
```

If the topic already exists, I ignore the warning.

Check it:

```powershell
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events
```

The topic should show 3 partitions and replication factor 3.

### 3. Fault tolerance test

First describe the topic:

```powershell
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events
```

Stop broker 2:

```powershell
docker stop kafka2
```

Describe the topic again:

```powershell
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events
```

Start the broker again:

```powershell
docker start kafka2
```

The details and screenshots are in `docs/fault_tolerance.md`.

### 4. Run the producer

```powershell
python src/producer.py --count 3000 --rate 5 --source site-A-rack-12
```

The Kafka key is the sensor type. That gives ordering per sensor type.

Example message:

```json
{
  "sensor": "temperature",
  "value": 31.67,
  "unit": "C",
  "timestamp": 1779152884491,
  "source": "site-A-rack-12",
  "anomaly": false
}
```

### 5. Run the Spark streaming pipeline

Command from the subject:

```bash
spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.3 src/spark_pipeline.py
```

On my Windows setup, global `spark-submit` was not found. I used the one inside the virtual environment:

```powershell
$project=(Get-Location).Path
$env:DATALAKE_ROOT="D:/tmp/datalake"
$env:SPARK_HOME="$project\venv\Lib\site-packages\pyspark"
$env:PYSPARK_PYTHON="$project\venv\Scripts\python.exe"
$env:PYSPARK_DRIVER_PYTHON="$project\venv\Scripts\python.exe"

.\venv\Scripts\spark-submit.cmd --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.3 src\spark_pipeline.py
```

Expected output:

```text
Pipeline started
raw path: D:/tmp/datalake/raw/source=kafka/topic=sensor-events
curated path: D:/tmp/datalake/curated/domain=iot
consumption path: D:/tmp/datalake/consumption/use_case=sensor_averages
```

I kept this terminal open, then ran the producer in another terminal.

### 6. Check the data lake

```powershell
dir D:\tmp\datalake\raw
dir D:\tmp\datalake\curated
dir D:\tmp\datalake\consumption
```

The consumption zone may appear later because it waits for the 5-minute window and the 2-minute watermark.

### 7. Run analytics

Command from the subject:

```bash
spark-submit src/analytics.py
```

Windows command I used:

```powershell
$project=(Get-Location).Path
$env:DATALAKE_ROOT="D:/tmp/datalake"
$env:SPARK_HOME="$project\venv\Lib\site-packages\pyspark"
$env:PYSPARK_PYTHON="$project\venv\Scripts\python.exe"
$env:PYSPARK_DRIVER_PYTHON="$project\venv\Scripts\python.exe"

.\venv\Scripts\spark-submit.cmd src\analytics.py
```

The script prints the results and writes CSV files under:

```text
outputs/analytics/
```

The actual numbers from my run are in `docs/analytics.md`.

### 8. Run the API

From the project root:

```powershell
cd src/api
python app.py
```

The API runs on:

```text
http://localhost:5000
```

PowerShell curl tests:

```powershell
curl.exe -s http://localhost:5000/api/v1/health
curl.exe -s http://localhost:5000/api/v1/sensors
curl.exe -s http://localhost:5000/api/v1/sensors/temperature/latest
curl.exe -s "http://localhost:5000/api/v1/sensors/temperature/stats?days=7"
curl.exe -s "http://localhost:5000/api/v1/anomalies?sensor=temperature&limit=5"
```

For POST, PowerShell handled quotes badly on my machine, so I used a small JSON file:

```powershell
'{"sensor":"temperature","value":37.5,"source":"manual-test"}' | Set-Content -Encoding ascii body.json
curl.exe -s -X POST "http://localhost:5000/api/v1/readings" -H "Content-Type: application/json" --data-binary "@body.json"
```

For bash, WSL, Git Bash or macOS:

```bash
bash tests/test_curl_commands.sh
```

## API endpoints

```text
GET  /api/v1/health
GET  /api/v1/sensors
GET  /api/v1/sensors/<type>/latest
GET  /api/v1/sensors/<type>/stats?days=N
GET  /api/v1/anomalies?sensor=<type>&limit=N
POST /api/v1/readings
```

## Technical choices

### Curated partitioning

I partitioned curated data by `sensor_type`, `year`, `month` and `day`. The analytics often filters by sensor or date, so this layout makes the folder structure useful. I considered only date partitions, but then a temperature-only query would still scan humidity and pressure files.

### Spark output mode

I used `append` mode for raw and curated data because records are only added. For the 5-minute aggregates, I also used append mode with a watermark, so Spark writes a result after the window is closed. I avoided update mode because writing updates to plain Parquet is less convenient.

### Kafka replication factor and min.insync.replicas

The topic uses replication factor 3, and the brokers use `min.insync.replicas=2`. With `acks=all`, Kafka can lose one broker and still accept reliable writes. Replication factor 1 would be simpler, but it would not show fault tolerance.

### Event time and ingestion time

Raw data is partitioned by ingestion time, because that zone records when Spark received the Kafka message. Curated and consumption data use event time from the sensor message. This is better for analytics, because the sensor time is the business time.

### Delivery semantics

This project is closest to at-least-once delivery. The producer retries and waits for acknowledgements, and Spark has checkpoints. I would not claim full exactly-once behavior because there are three sinks and an API writer. A crash in the middle could still leave something to check.

## Results

Some results from my analytics run:

```text
Top anomaly hour:
2026-05-19 hour 9, anomaly_count = 242

Sensor stats:
humidity    mean=58.36    anomaly_rate=9.54
pressure    mean=1009.47  anomaly_rate=12.79
temperature mean=27.1     anomaly_rate=16.08

Partition pruning:
full count = 3832
filtered count = 1604
full scan = 0.5157 seconds
filtered scan = 0.1667 seconds
speedup = 3.09
```

API calls tested:

```text
GET /api/v1/health
GET /api/v1/sensors
GET /api/v1/sensors/temperature/latest
GET /api/v1/sensors/temperature/stats?days=7
GET /api/v1/anomalies?sensor=temperature&limit=5
POST /api/v1/readings
```

Screenshots:

Kafka UI topic overview. This screenshot shows `sensor-events` with 3 partitions, replication factor 3, all replicas in sync, and 5081 messages.

![Kafka UI topic overview](outputs/screenshots/ui.png)

Kafka UI consumer group lag. This screenshot shows consumer group `sensor-analytics` with total lag 4654 on topic `sensor-events`.

![Kafka UI consumer lag](outputs/screenshots/lag.png)

API test output:

![API test output](outputs/screenshots/12-1.png)

## Limitations and improvements

This is a local exam project, so there are some rough edges.

```text
- Spark runs locally, not on a cluster.
- The API reads Kafka by scanning messages, which is slow for a large topic.
- The API starts Spark locally when reading data lake statistics.
- I did not add authentication.
- Invalid records are filtered, but there is no separate quarantine zone.
- Windows Spark commands are different from the Linux commands in the subject.
```

With more time, I would clean the API reads, add a quarantine folder, write more tests, and take cleaner screenshots.
