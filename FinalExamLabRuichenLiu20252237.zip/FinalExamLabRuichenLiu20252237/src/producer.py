import argparse
import json
import random
import time
from kafka import KafkaProducer

topic_name = "sensor-events"

sensors = ["temperature", "humidity", "pressure"]

units = {
    "temperature": "C",
    "humidity": "%",
    "pressure": "hPa"
}


def get_value(sensor, is_bad):
    if sensor == "temperature":
        if is_bad:
            return round(random.uniform(36, 45), 2)
        return round(random.uniform(15, 35), 2)

    if sensor == "humidity":
        if is_bad:
            return round(random.uniform(91, 95), 2)
        return round(random.uniform(30, 90), 2)

    if sensor == "pressure":
        if is_bad:
            if random.random() < 0.5:
                return round(random.uniform(980, 989), 2)
            else:
                return round(random.uniform(1031, 1040), 2)
        return round(random.uniform(990, 1030), 2)


parser = argparse.ArgumentParser()
parser.add_argument("--count", type=int, default=100)
parser.add_argument("--rate", type=float, default=5)
parser.add_argument("--source", type=str, default="site-A-rack-12")
args = parser.parse_args()

producer = KafkaProducer(
    bootstrap_servers=["localhost:9092", "localhost:9094", "localhost:9096"],
    acks="all",
    retries=5,
    max_in_flight_requests_per_connection=1,
    linger_ms=20,
    batch_size=32768,
    key_serializer=lambda k: k.encode("utf-8"),
    value_serializer=lambda v: json.dumps(v).encode("utf-8")
)

try:
    for i in range(args.count):
        sensor = random.choice(sensors)

        # a bit more than 10 percent, so I can test anomalies
        bad = random.random() < 0.12

        value = get_value(sensor, bad)

        msg = {
            "sensor": sensor,
            "value": value,
            "unit": units[sensor],
            "timestamp": int(time.time() * 1000),
            "source": args.source,
            "anomaly": bad
        }

        result = producer.send(topic_name, key=sensor, value=msg).get(timeout=10)

        print(
            i + 1,
            "/",
            args.count,
            sensor,
            value,
            units[sensor],
            "anomaly=",
            bad,
            "partition=",
            result.partition,
            "offset=",
            result.offset
        )

        if args.rate > 0:
            time.sleep(1 / args.rate)

except KeyboardInterrupt:
    print("Stopped")

finally:
    producer.flush()
    producer.close()
    print("Producer finished")