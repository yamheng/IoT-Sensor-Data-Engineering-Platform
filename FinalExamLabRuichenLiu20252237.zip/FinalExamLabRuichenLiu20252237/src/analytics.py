import os
import time

from pyspark.sql import SparkSession

lake = os.environ.get("DATALAKE_ROOT", "/tmp/datalake")
curated_path = lake + "/curated/domain=iot"
output_dir = "outputs/analytics"

spark = SparkSession.builder.appName("analytics").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

df = spark.read.parquet(curated_path)
df.createOrReplaceTempView("sensors")

print("Query 1: top 5 hours with anomalies")
q1 = spark.sql("""
SELECT
    year,
    month,
    day,
    hour(event_time) as hour,
    count(*) as anomaly_count
FROM sensors
WHERE is_anomaly = true
GROUP BY year, month, day, hour(event_time)
ORDER BY anomaly_count DESC
LIMIT 5
""")
q1.show(truncate=False)
q1.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_dir + "/query1_top_hours")

print("Query 2: stats by sensor")
q2 = spark.sql("""
SELECT
    sensor_type,
    round(avg(value), 2) as mean_value,
    round(min(value), 2) as min_value,
    round(max(value), 2) as max_value,
    round(stddev(value), 2) as std_value,
    round(100 * sum(cast(is_anomaly as int)) / count(*), 2) as anomaly_rate
FROM sensors
GROUP BY sensor_type
ORDER BY sensor_type
""")
q2.show(truncate=False)
q2.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_dir + "/query2_sensor_stats")

print("Query 3: daily temperature")
q3 = spark.sql("""
SELECT
    year,
    month,
    day,
    round(avg(value), 2) as mean_temperature,
    sum(cast(is_anomaly as int)) as anomaly_count
FROM sensors
WHERE sensor_type = 'temperature'
GROUP BY year, month, day
ORDER BY year, month, day
""")
q3.show(truncate=False)
q3.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_dir + "/query3_temperature_daily")

print("Query 4: partition pruning test")

start = time.time()
all_count = spark.sql("SELECT count(*) as c FROM sensors").collect()[0]["c"]
time1 = time.time() - start

start = time.time()
temp_count = spark.sql("""
SELECT count(*) as c
FROM sensors
WHERE sensor_type = 'temperature'
""").collect()[0]["c"]
time2 = time.time() - start

speed = 0
if time2 > 0:
    speed = time1 / time2

print("full count:", all_count)
print("filtered count:", temp_count)
print("full scan seconds:", round(time1, 4))
print("filtered seconds:", round(time2, 4))
print("speedup:", round(speed, 2))

rows = [(all_count, round(time1, 4), temp_count, round(time2, 4), round(speed, 2))]
q4 = spark.createDataFrame(rows, ["full_count", "full_time", "filtered_count", "filtered_time", "speedup"])
q4.show(truncate=False)
q4.coalesce(1).write.mode("overwrite").option("header", "true").csv(output_dir + "/query4_pruning")

spark.stop()