import os

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

kafka_servers = "localhost:9092,localhost:9094,localhost:9096"
topic_name = "sensor-events"

lake = os.environ.get("DATALAKE_ROOT", "/tmp/datalake")

raw_path = lake + "/raw/source=kafka/topic=sensor-events"
curated_path = lake + "/curated/domain=iot"
consumption_path = lake + "/consumption/use_case=sensor_averages"

raw_checkpoint = lake + "/_checkpoints/raw"
curated_checkpoint = lake + "/_checkpoints/curated"
consumption_checkpoint = lake + "/_checkpoints/consumption"

spark = (
    SparkSession.builder
    .appName("iot sensor pipeline")
    .config("spark.sql.shuffle.partitions", "3")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

schema = StructType([
    StructField("sensor", StringType(), True),
    StructField("value", DoubleType(), True),
    StructField("unit", StringType(), True),
    StructField("timestamp", LongType(), True),
    StructField("source", StringType(), True),
    StructField("anomaly", BooleanType(), True)
])

kafka_df = (
    spark.readStream
    .format("kafka")
    .option("kafka.bootstrap.servers", kafka_servers)
    .option("subscribe", topic_name)
    .option("startingOffsets", "earliest")
    .load()
)

raw_data = (
    kafka_df
    .select(
        col("value").cast("string").alias("raw_json"),
        col("partition").alias("kafka_partition"),
        col("offset").alias("kafka_offset"),
        col("timestamp").alias("ingestion_time")
    )
    .withColumn("year", year(col("ingestion_time")))
    .withColumn("month", month(col("ingestion_time")))
    .withColumn("day", dayofmonth(col("ingestion_time")))
    .withColumn("hour", hour(col("ingestion_time")))
)

parsed = (
    kafka_df
    .select(
        from_json(col("value").cast("string"), schema).alias("data"),
        col("partition").alias("kafka_partition"),
        col("offset").alias("kafka_offset")
    )
    .select(
        col("data.sensor").alias("sensor_type"),
        col("data.value").alias("value"),
        col("data.unit").alias("unit"),
        col("data.timestamp").alias("timestamp_ms"),
        col("data.source").alias("source"),
        col("data.anomaly").alias("producer_anomaly"),
        col("kafka_partition"),
        col("kafka_offset")
    )
)

parsed = parsed.filter(col("sensor_type").isNotNull())
parsed = parsed.filter(col("value").isNotNull())
parsed = parsed.filter(col("timestamp_ms").isNotNull())

parsed = parsed.withColumn(
    "event_time",
    from_unixtime(col("timestamp_ms") / 1000).cast("timestamp")
)

good_data = parsed.filter(
    ((col("sensor_type") == "temperature") & (col("value") >= 15) & (col("value") <= 45)) |
    ((col("sensor_type") == "humidity") & (col("value") >= 30) & (col("value") <= 95)) |
    ((col("sensor_type") == "pressure") & (col("value") >= 980) & (col("value") <= 1040))
)

curated = good_data.withColumn(
    "is_anomaly",
    when((col("sensor_type") == "temperature") & (col("value") > 35), True)
    .when((col("sensor_type") == "humidity") & (col("value") > 90), True)
    .when((col("sensor_type") == "pressure") & ((col("value") < 990) | (col("value") > 1030)), True)
    .otherwise(False)
)

curated = curated.withColumn("year", year(col("event_time")))
curated = curated.withColumn("month", month(col("event_time")))
curated = curated.withColumn("day", dayofmonth(col("event_time")))

avg_data = (
    curated
    .withWatermark("event_time", "2 minutes")
    .groupBy(
        window(col("event_time"), "5 minutes"),
        col("sensor_type")
    )
    .agg(
        avg("value").alias("mean_value"),
        min("value").alias("min_value"),
        max("value").alias("max_value"),
        count("*").alias("observation_count"),
        sum(col("is_anomaly").cast("int")).alias("anomaly_count")
    )
)

avg_data = avg_data.withColumn("window_start", col("window.start"))
avg_data = avg_data.withColumn("window_end", col("window.end"))
avg_data = avg_data.withColumn("year", year(col("window_start")))
avg_data = avg_data.withColumn("month", month(col("window_start")))
avg_data = avg_data.drop("window")

q1 = (
    raw_data.writeStream
    .format("json")
    .outputMode("append")
    .option("path", raw_path)
    .option("checkpointLocation", raw_checkpoint)
    .partitionBy("year", "month", "day", "hour")
    .start()
)

q2 = (
    curated.writeStream
    .format("parquet")
    .outputMode("append")
    .option("path", curated_path)
    .option("checkpointLocation", curated_checkpoint)
    .option("compression", "snappy")
    .partitionBy("sensor_type", "year", "month", "day")
    .start()
)

q3 = (
    avg_data.writeStream
    .format("parquet")
    .outputMode("append")
    .option("path", consumption_path)
    .option("checkpointLocation", consumption_checkpoint)
    .option("compression", "snappy")
    .partitionBy("sensor_type", "year", "month")
    .start()
)

print("Pipeline started")
print("raw path:", raw_path)
print("curated path:", curated_path)
print("consumption path:", consumption_path)

spark.streams.awaitAnyTermination()