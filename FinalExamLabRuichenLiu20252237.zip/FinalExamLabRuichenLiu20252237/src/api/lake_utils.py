import os

from pyspark.sql import SparkSession
from pyspark.sql.functions import col

lake = os.environ.get("DATALAKE_ROOT", "/tmp/datalake")
curated_path = lake + "/curated/domain=iot"


def get_spark():
    spark = SparkSession.builder.appName("api lake reader").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    return spark


def get_stats(sensor_type, days):
    if not os.path.exists(curated_path):
        return None

    spark = get_spark()

    df = spark.read.parquet(curated_path)
    df = df.filter(col("sensor_type") == sensor_type)

    result = (
        df.groupBy("year", "month", "day")
        .agg(
            {"value": "avg", "*": "count"}
        )
        .orderBy(col("year").desc(), col("month").desc(), col("day").desc())
        .limit(days)
    )

    rows = result.collect()
    answer = []

    for r in rows:
        answer.append({
            "year": int(r["year"]),
            "month": int(r["month"]),
            "day": int(r["day"]),
            "avg_value": float(r["avg(value)"]),
            "count": int(r["count(1)"])
        })

    spark.stop()
    return answer


def get_anomalies(sensor_type, limit_num):
    if not os.path.exists(curated_path):
        return []

    spark = get_spark()

    df = spark.read.parquet(curated_path)
    df = df.filter(col("is_anomaly") == True)

    if sensor_type is not None:
        df = df.filter(col("sensor_type") == sensor_type)

    rows = df.orderBy(col("event_time").desc()).limit(limit_num).collect()

    answer = []

    for r in rows:
        answer.append({
            "sensor": r["sensor_type"],
            "value": float(r["value"]),
            "unit": r["unit"],
            "source": r["source"],
            "event_time": str(r["event_time"])
        })

    spark.stop()
    return answer