import time
from flask import Flask, jsonify, request

from kafka_utils import send_to_kafka, read_latest
from lake_utils import get_stats, get_anomalies

app = Flask(__name__)

valid_sensors = ["temperature", "humidity", "pressure"]

units = {
    "temperature": "C",
    "humidity": "%",
    "pressure": "hPa"
}


@app.route("/api/v1/health")
def health():
    return jsonify({
        "status": "success",
        "data": {
            "service": "sensor api",
            "ok": True
        }
    }), 200


@app.route("/api/v1/sensors")
def sensors():
    return jsonify({
        "status": "success",
        "data": valid_sensors
    }), 200


@app.route("/api/v1/sensors/<sensor_type>/latest")
def latest(sensor_type):
    if sensor_type not in valid_sensors:
        return jsonify({
            "status": "error",
            "message": "unknown sensor"
        }), 404

    item = read_latest(sensor_type)

    if item is None:
        return jsonify({
            "status": "error",
            "message": "no data found"
        }), 404

    return jsonify({
        "status": "success",
        "data": item
    }), 200


@app.route("/api/v1/sensors/<sensor_type>/stats")
def stats(sensor_type):
    if sensor_type not in valid_sensors:
        return jsonify({
            "status": "error",
            "message": "unknown sensor"
        }), 404

    days_text = request.args.get("days", "7")

    try:
        days = int(days_text)
    except:
        return jsonify({
            "status": "error",
            "message": "days must be an integer"
        }), 400

    if days < 1 or days > 90:
        return jsonify({
            "status": "error",
            "message": "days must be between 1 and 90"
        }), 422

    data = get_stats(sensor_type, days)

    if data is None:
        return jsonify({
            "status": "error",
            "message": "data lake not found"
        }), 404

    return jsonify({
        "status": "success",
        "data": data
    }), 200


@app.route("/api/v1/anomalies")
def anomalies():
    sensor_type = request.args.get("sensor")
    limit_text = request.args.get("limit", "10")

    if sensor_type is not None and sensor_type not in valid_sensors:
        return jsonify({
            "status": "error",
            "message": "bad sensor"
        }), 400

    try:
        limit_num = int(limit_text)
    except:
        return jsonify({
            "status": "error",
            "message": "limit must be integer"
        }), 400

    data = get_anomalies(sensor_type, limit_num)

    return jsonify({
        "status": "success",
        "data": data
    }), 200


@app.route("/api/v1/readings", methods=["POST"])
def readings():
    body = request.get_json(silent=True)

    if body is None:
        return jsonify({
            "status": "error",
            "message": "invalid json"
        }), 400

    if "sensor" not in body or "value" not in body:
        return jsonify({
            "status": "error",
            "message": "sensor and value are required"
        }), 400

    sensor = body["sensor"]

    if sensor not in valid_sensors:
        return jsonify({
            "status": "error",
            "message": "invalid sensor"
        }), 422

    try:
        value = float(body["value"])
    except:
        return jsonify({
            "status": "error",
            "message": "value must be numeric"
        }), 422

    anomaly = False
    if sensor == "temperature" and value > 35:
        anomaly = True
    if sensor == "humidity" and value > 90:
        anomaly = True
    if sensor == "pressure" and (value < 990 or value > 1030):
        anomaly = True

    reading = {
        "sensor": sensor,
        "value": value,
        "unit": units[sensor],
        "timestamp": int(time.time() * 1000),
        "source": body.get("source", "api"),
        "anomaly": anomaly
    }

    info = send_to_kafka(reading)

    return jsonify({
        "status": "success",
        "data": {
            "reading": reading,
            "kafka": info
        }
    }), 201


@app.errorhandler(404)
def error_404(e):
    return jsonify({
        "status": "error",
        "message": "not found"
    }), 404


@app.errorhandler(405)
def error_405(e):
    return jsonify({
        "status": "error",
        "message": "method not allowed"
    }), 405


@app.errorhandler(500)
def error_500(e):
    app.logger.error(str(e))
    return jsonify({
        "status": "error",
        "message": "server error"
    }), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)