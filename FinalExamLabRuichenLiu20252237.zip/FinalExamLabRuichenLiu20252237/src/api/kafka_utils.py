import json
from kafka import KafkaProducer, KafkaConsumer

topic_name = "sensor-events"
servers = ["localhost:9092", "localhost:9094", "localhost:9096"]


def send_to_kafka(reading):
    producer = KafkaProducer(
        bootstrap_servers=servers,
        acks="all",
        retries=5,
        max_in_flight_requests_per_connection=1,
        key_serializer=lambda k: k.encode("utf-8"),
        value_serializer=lambda v: json.dumps(v).encode("utf-8")
    )

    data = producer.send(topic_name, key=reading["sensor"], value=reading).get(timeout=10)
    producer.flush()
    producer.close()

    return {
        "partition": data.partition,
        "offset": data.offset
    }


def read_latest(sensor_type):
    consumer = KafkaConsumer(
        topic_name,
        bootstrap_servers=servers,
        auto_offset_reset="earliest",
        enable_auto_commit=False,
        consumer_timeout_ms=3000,
        value_deserializer=lambda b: json.loads(b.decode("utf-8"))
    )

    latest = None

    for msg in consumer:
        item = msg.value

        if item.get("sensor") == sensor_type:
            if latest is None:
                latest = item
            else:
                if item.get("timestamp", 0) > latest.get("timestamp", 0):
                    latest = item

    consumer.close()
    return latest