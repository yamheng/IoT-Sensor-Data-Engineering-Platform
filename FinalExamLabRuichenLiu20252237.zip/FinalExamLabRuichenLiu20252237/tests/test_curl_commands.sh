#!/usr/bin/env bash

set -u

BASE_URL="http://localhost:5000"
BODY_FILE="/tmp/sensor_reading_body.json"

echo "1. Health check"
curl -s "$BASE_URL/api/v1/health"
echo
echo

echo "2. List sensors"
curl -s "$BASE_URL/api/v1/sensors"
echo
echo

echo "3. Latest temperature reading"
curl -s "$BASE_URL/api/v1/sensors/temperature/latest"
echo
echo

echo "4. Temperature stats for 7 days"
curl -s "$BASE_URL/api/v1/sensors/temperature/stats?days=7"
echo
echo

echo "5. Recent temperature anomalies"
curl -s "$BASE_URL/api/v1/anomalies?sensor=temperature&limit=5"
echo
echo

echo "6. Post a new reading"
cat > "$BODY_FILE" <<'JSON'
{"sensor":"temperature","value":37.5,"source":"manual-test"}
JSON

curl -s -X POST "$BASE_URL/api/v1/readings" \
  -H "Content-Type: application/json" \
  --data-binary "@$BODY_FILE"
echo
echo

rm -f "$BODY_FILE"

echo "Done"
