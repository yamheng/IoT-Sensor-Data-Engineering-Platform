# Kafka fault tolerance test

I tested `sensor-events` by stopping `kafka2`.

## Before stopping kafka2

Command:

```bash
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events
```

Output:

```text
Topic: sensor-events    PartitionCount: 3    ReplicationFactor: 3    Configs: min.insync.replicas=2
Partition: 0    Leader: 3    Replicas: 3,1,2    Isr: 3,1,2
Partition: 1    Leader: 1    Replicas: 1,2,3    Isr: 3,1,2
Partition: 2    Leader: 2    Replicas: 2,3,1    Isr: 3,1,2
```

## Stop one broker

Command:

```bash
docker stop kafka2
```

## After stopping kafka2

Command:

```bash
docker exec kafka1 kafka-topics --bootstrap-server kafka1:29092 --describe --topic sensor-events
```

Output:

```text
Topic: sensor-events    PartitionCount: 3    ReplicationFactor: 3    Configs: min.insync.replicas=2
Partition: 0    Leader: 3    Replicas: 3,1,2    Isr: 3,1
Partition: 1    Leader: 1    Replicas: 1,2,3    Isr: 3,1
Partition: 2    Leader: 3    Replicas: 2,3,1    Isr: 3,1
```

## Comment

Before the test, all brokers were in the ISR: `3,1,2`.

After stopping `kafka2`, broker 2 disappeared from the ISR. Partition 2 had broker 2 as leader before the test, and Kafka moved the leader to broker 3. The topic stayed available, which is what I expected with replication factor 3 and `min.insync.replicas=2`.

![Before stopping kafka2](../outputs/screenshots/5-1.png)

![After stopping kafka2](../outputs/screenshots/5-2.png)
