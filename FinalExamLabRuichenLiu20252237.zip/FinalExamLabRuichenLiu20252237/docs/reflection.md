# Reflection questions

## 1. Crash after raw write, before curated write

If the job crashes after raw output but before curated output, the lake is not fully aligned for that batch. The raw JSON exists, but the cleaned Parquet records may be missing. Analytics and API stats would then read less data than what actually arrived.

The raw zone still helps because the original payloads are not lost. I used separate checkpoints for raw, curated and consumption sinks, so Spark can restart each sink from its saved progress. A stronger version would also add a small recovery check that compares raw and curated counts and reprocesses missing data if needed.

## 2. Producer scaled to 50,000 messages per second

At 50,000 messages per second, I expect Kafka disk I/O to be one of the first problems. The producer uses `acks=all`, replication factor 3 and `min.insync.replicas=2`, so Kafka writes the data safely to more than one broker. That is reliable, but not cheap.

Spark would probably be the next bottleneck. JSON parsing, watermarking, window aggregation and Parquet writing all run locally in this project. To handle that rate, I would add more Kafka partitions, run Spark on a real cluster, tune producer batching, and watch consumer lag closely.

## 3. Kafka as source of truth vs Parquet data lake

Kafka is a good short-term source for recent streaming events. It preserves order inside partitions and lets a consumer replay messages while they are still inside Kafka retention.

The Parquet data lake is better for history. It is cheaper to keep days or months of data there, and Spark SQL can scan partitioned Parquet files efficiently.

For this project, Kafka is the ingestion and replay layer. The data lake is the historical storage layer.

## 4. Broken sensor emitting aberrant values for 2 hours

The Spark pipeline marks abnormal readings with `is_anomaly`. For example, temperature above 35, humidity above 90, and pressure below 990 or above 1030 are flagged.

If a sensor breaks for two hours, the anomaly count should increase for that time period. The top-anomaly-hours query would show it. I would keep the raw records instead of deleting them. In a better version, I would write suspicious records to a quarantine zone or add a `quality_status` column.

## 5. Adding a new sensor type `co2`

I would change these files:

```text
src/producer.py
src/spark_pipeline.py
src/api/app.py
docs/*.md
tests/test_curl_commands.sh
```

In `src/producer.py`, I would add `co2`, choose `ppm` as the unit, and define normal and anomaly ranges.

In `src/spark_pipeline.py`, I would add CO2 to the validation filter and add a CO2 anomaly rule. The JSON schema can stay the same because it already uses generic fields.

In `src/api/app.py`, I would add `co2` to `valid_sensors`, add the unit, and update the POST anomaly rule.

`src/analytics.py` would mostly keep working because it groups by `sensor_type`. I would still update the README, architecture notes and curl examples so the new sensor is documented.
