# Analytics results

I ran:

```bash
spark-submit src/analytics.py
```

On Windows I used the venv Spark command:

```powershell
.\venv\Scripts\spark-submit.cmd src\analytics.py
```

The script reads the curated Parquet files and writes CSV output to `outputs/analytics/`.

## Query 1 - Top 5 hours with most anomalies

This query counts anomalies by hour, using all sensor types.

| year | month | day | hour | anomaly_count |
|---|---|---|---|---|
| 2026 | 5 | 19 | 9 | 242 |
| 2026 | 5 | 19 | 8 | 135 |
| 2026 | 5 | 18 | 10 | 38 |
| 2026 | 5 | 14 | 13 | 26 |
| 2026 | 5 | 17 | 19 | 24 |

The highest value was 242 anomalies on 2026-05-19 at hour 9. That was during my final data generation run, so the number is higher than the older dates.

CSV output:

```text
outputs/analytics/query1_top_hours/
```

## Query 2 - Statistics by sensor type

This query gives the global statistics for each sensor.

| sensor_type | mean_value | min_value | max_value | std_value | anomaly_rate |
|---|---:|---:|---:|---:|---:|
| humidity | 58.36 | 30.0 | 94.91 | 20.99 | 9.54 |
| pressure | 1009.47 | 980.03 | 1039.93 | 14.23 | 12.79 |
| temperature | 27.1 | 15.0 | 44.78 | 7.46 | 16.08 |

The min and max values match the ranges used by the producer. The anomaly rates are different because the sensor type is chosen randomly.

CSV output:

```text
outputs/analytics/query2_sensor_stats/
```

## Query 3 - Daily temperature evolution

This query keeps only temperature readings.

| year | month | day | mean_temperature | anomaly_count |
|---|---|---|---:|---:|
| 2026 | 5 | 12 | 28.25 | 31 |
| 2026 | 5 | 13 | 26.34 | 7 |
| 2026 | 5 | 14 | 26.89 | 26 |
| 2026 | 5 | 17 | 27.08 | 24 |
| 2026 | 5 | 18 | 27.92 | 38 |
| 2026 | 5 | 19 | 26.88 | 132 |

The average temperature is stable, around 26 to 28 degrees. The anomaly count is much larger on May 19 because I generated more data that day.

CSV output:

```text
outputs/analytics/query3_temperature_daily/
```

## Query 4 - Partition pruning test

I compared a full count on the curated data lake with a count filtered on `sensor_type = 'temperature'`.

| full_count | full_time | filtered_count | filtered_time | speedup |
|---:|---:|---:|---:|---:|
| 3832 | 0.5157 | 1604 | 0.1667 | 3.09 |

The filtered query was faster. Since `sensor_type` is a partition column, Spark can skip the humidity and pressure folders. On this small local dataset, the speedup was 3.09x.

CSV output:

```text
outputs/analytics/query4_pruning/
```

## Screenshot

![Analytics output](../outputs/screenshots/10-1.png)

## Short note

The four required queries ran successfully. The CSV outputs were created under `outputs/analytics/`.
