# Architecture

This project is a local IoT data pipeline. It sends sensor readings to Kafka, processes them with Spark, stores them in a data lake, and exposes some results through a Flask API.

## Global view

```text
+------------------+
| Python producer  |
| src/producer.py  |
+--------+---------+
         |
         | JSON messages
         v
+-----------------------------+
| Kafka cluster               |
| 3 brokers in Docker         |
| topic: sensor-events        |
+--------+--------------------+
         |
         | Spark Structured Streaming
         v
+-----------------------------+
| Spark pipeline              |
| src/spark_pipeline.py       |
| parse JSON                  |
| clean invalid values        |
| detect anomalies            |
| 5-minute aggregations       |
+--------+--------------------+
         |
         v
+-----------------------------+
| Local data lake             |
| raw / curated / consumption |
+--------+--------------------+
         |
         +----------------------+
         |                      |
         v                      v
+------------------+     +------------------+
| Analytics script |     | Flask API        |
| src/analytics.py |     | src/api/app.py   |
+------------------+     +------------------+
```

## Components

### Producer

`src/producer.py` generates random readings for:

```text
temperature
humidity
pressure
```

It sends them to `sensor-events`. The message key is the sensor type, for example `temperature`, so Kafka keeps the order for that type inside a partition.

Producer reliability settings:

```text
acks = all
retries = 5
max_in_flight_requests_per_connection = 1
```

These settings are slower than weak settings, but they match the reliability part of the subject.

### Kafka

Kafka runs in Docker with:

```text
kafka1
kafka2
kafka3
```

The topic configuration is:

```text
topic: sensor-events
partitions: 3
replication factor: 3
min.insync.replicas: 2
```

Kafka UI runs at:

```text
http://localhost:8080
```

### Spark streaming pipeline

`src/spark_pipeline.py` reads from Kafka and does this work:

```text
1. read Kafka messages
2. parse JSON with an explicit schema
3. drop records with missing fields
4. filter values outside the expected ranges
5. calculate is_anomaly in Spark
6. calculate 5-minute window statistics
7. write raw, curated and consumption zones
```

Spark anomaly rules:

```text
temperature > 35
humidity > 90
pressure < 990 or pressure > 1030
```

The stream uses a 2-minute watermark on `event_time`.

### Data lake

Raw zone:

```text
raw/source=kafka/topic=sensor-events/year=YYYY/month=MM/day=DD/hour=HH/
```

This keeps the raw JSON from Kafka.

Curated zone:

```text
curated/domain=iot/sensor_type=.../year=YYYY/month=MM/day=DD/
```

This stores cleaned Parquet data, partitioned for later queries.

Consumption zone:

```text
consumption/use_case=sensor_averages/sensor_type=.../year=YYYY/month=MM/
```

This stores the 5-minute aggregate results.

Checkpoints are separated:

```text
_checkpoints/raw
_checkpoints/curated
_checkpoints/consumption
```

### Analytics

`src/analytics.py` reads the curated Parquet data and runs:

```text
1. top 5 anomaly hours
2. stats by sensor type
3. daily temperature evolution
4. partition pruning test
```

CSV files are written under:

```text
outputs/analytics/
```

### REST API

The API is in `src/api/app.py`.

```text
GET  /api/v1/health
GET  /api/v1/sensors
GET  /api/v1/sensors/<type>/latest
GET  /api/v1/sensors/<type>/stats?days=N
GET  /api/v1/anomalies?sensor=<type>&limit=N
POST /api/v1/readings
```

The API reads latest values from Kafka, reads statistics from the data lake, and can publish one new reading to Kafka.

## Data flow

```text
producer creates JSON
Kafka stores it in sensor-events
Spark reads it from Kafka
Spark writes raw JSON to raw zone
Spark writes cleaned data to curated zone
Spark writes 5-minute aggregates to consumption zone
analytics.py reads curated zone
src/api/app.py reads Kafka and the data lake
```

## Notes

The architecture is intentionally small. It is enough to run on my machine and show the full pipeline, but it is not meant to be a production design.
